Bienvenue dans ce repository contenant mes scripts R d'analyse.
Ne seront présentées que les versions finales utilisées pour générer les images et résultats présents dans le Mémoire.

- Aucune information confidentielle n'est contenue.
- Les données des essais non confidentiels sont fournies au moyen de fichiers .csv, et leur utilisation est automatique
- Les données des essais confidentiels ne sont pas fournies et ne seront pas analysées dans ces scripts

Bonne lecture !
